import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-fetchloans',
  templateUrl: './fetchloans.component.html',
  styleUrls: ['./fetchloans.component.css']
})
export class FetchloansComponent implements OnInit {
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['loanId', 'accountNo', 'amount', 'loanType', 'rateOfInterest','tenure','emi','approvedDate','loanStatus','employeeId'];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  searchKey: string;
  constructor(private service:LoanService) { }

  ngOnInit(): void {
    this.service.getLoans().subscribe(
array=>
{
        this.listData = new MatTableDataSource(array);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
        // this.listData.filterPredicate = (data, filter) => {
        //   return this.displayedColumns.some(ele => {
        //     return data[ele].toLowerCase().indexOf(filter) != -1;
        //   });
        // };
        
        console.log(this.listData.data.length)
      });
  }
  onSearchClear() {
    this.searchKey = "";
    this.applyFilter();
  }

  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }
  
}
