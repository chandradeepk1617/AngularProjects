import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoanService } from '../loan.service';
import { NotificationService } from '../notification.service';

@Component({
  selector: 'app-loanrequest',
  templateUrl: './loanrequest.component.html',
  styleUrls: ['./loanrequest.component.css']
})
export class LoanrequestComponent implements OnInit {
  AccountNumberForm: FormGroup;
  formVisibility: Boolean;
  accountNo: number;
  formBuilder: any;
  LoanRequestForm: FormGroup;

  constructor(private notification:NotificationService,private service:LoanService) { }

  ngOnInit(): void {
    this.AccountNumberForm = new FormGroup({
      accountNo: new FormControl('',[Validators.required,Validators.pattern("[1-9][0-9]{9}")])})

      this.LoanRequestForm = new FormGroup({
        loanRequestId: new FormControl(null),
        accountNo: new FormControl(''),
        amount:new FormControl('',[Validators.required,Validators.min(10000),Validators.max(2000000),Validators.pattern("^[0-9]+(\.[0-9]{1,2})?$")]),
        loanType: new FormControl('', Validators.required),
        rateOfInterest: new FormControl('', [Validators.required,Validators.min(4),Validators.max(15),Validators.pattern("[0-9]+(\.[0-9]{1,2})?$")]),
        tenure: new FormControl('',[Validators.required,Validators.min(12),Validators.max(240),Validators.pattern("[0-9]{1,3}")]),
        creditScore: new FormControl('',[Validators.required,Validators.min(0),Validators.max(999),Validators.pattern("[0-9]{1,3}")]),
        loanStatus: new FormControl(null),
        employeeId: new FormControl(null),
        
      });
    
  }
  checkAccountNo()
  {
    this.service.checkAccountNumber(this.AccountNumberForm.get('accountNo').value).subscribe(
    data=>
    {
      
      if(data==true){
      this.formVisibility=true;
      this.accountNo=this.AccountNumberForm.get('accountNo').value;
      this.LoanRequestForm.patchValue({"accountNo":this.AccountNumberForm.get('accountNo').value,})
      this.AccountNumberForm.disable();
      }
      
  
    }, 
    error=>
    {
      
        this.notification.warn("Account Number "+ this.AccountNumberForm.get('accountNo').value +" doesnot Exist");
        this.AccountNumberForm.reset();
        this.AccountNumberForm.patchValue({"accountNo":''});
      
      console.log(error.error)
    })

   
  }



  onClear()
  {
    this.LoanRequestForm.reset();
    this.LoanRequestForm.patchValue(
      {
       accountNo: this.accountNo,
       amount:'',
       loanType: '',
       rateOfInterest:'',
       tenure: '',
       creditScore: '',
      })
  }
  resetForm()
  {
    this.LoanRequestForm.reset();
    this.LoanRequestForm.patchValue(
      {
       accountNo:'',
       amount:'',
       loanType: '',
       rateOfInterest:'',
       tenure: '',
       creditScore: '',
      })
  }
  submit()
  {this.service.addLoanRequest(this.LoanRequestForm.value).subscribe(
    data=>
    { 
    this.notification.success("Loan Request added successfully");
    this.resetForm();
    this.formVisibility=false;
    this.AccountNumberForm.reset();
    this.AccountNumberForm.enable();


    },
    error=>
    {
      console.log(error)
    }
  )
  }

  newRequest()
  { this.AccountNumberForm.enable();
    this.AccountNumberForm.patchValue({"accountNo":''});
    this.formVisibility=false;
    this.resetForm();
  }
   
    
  

}
