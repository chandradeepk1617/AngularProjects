export class Employee{
    empName:string;
    empId:number;
    empSalary:number;
    deptId:number;
    dateofbirth:Date;
    contactNumber:number;
    managerId:number;
    numofLeaves:number;
    designation:string;
  
    constructor(empName,empId,empSalary,deptId,dob,contactNumber,managerId,numOfLeaves,designation)
    {
        
        this.empName=empName;
        this.empId=empId;
        this.empSalary=empSalary;
        this.deptId=deptId;
        this.dateofbirth=dob;
        this.contactNumber=contactNumber;
        this.managerId=managerId;
        this.numofLeaves=numOfLeaves;
        this.designation=designation;
    }
}