import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource} from '@angular/material/table';
import { AccountService } from 'src/app/shared/services/account.service';

@Component({
  selector: 'app-passbook',
  templateUrl: './passbook.component.html',
  styleUrls: ['./passbook.component.css']
})
export class PassbookComponent implements OnInit {
  listData: MatTableDataSource<any>;
  constructor(private service:AccountService) { }
  displayedColumns: string[] = ['accountNumber', 'aadhar', 'amount', 'ifsc', 'branchId','status','accountType','actions'];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngOnInit(): void {
    // this.service.getAll().subscribe(
    //   list => {
    //     let array = list.map(item => {
    //       return {

    //         ...item
    //       };
    //     });
    //     this.listData = new MatTableDataSource(array);
    //     this.listData.sort = this.sort;
    //     this.listData.paginator = this.paginator;
     
    //   });
  }

}
