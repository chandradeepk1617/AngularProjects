import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DefaultModule } from './layouts/default/default.module';
import { AddAccountComponent } from './modules/add-account/add-account.component';
import { UpdateCustomerComponent } from './modules/update-customer/update-customer.component';
import { DeleteAccountComponent } from './modules/delete-account/delete-account.component';
import { CustomerDetailsComponent } from './modules/customer-details/customer-details.component';
import { AccountDetailsComponent } from './modules/account-details/account-details.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from './shared/shared.module';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { AccountService } from './shared/services/account.service';
import { HttpClientModule } from '@angular/common/http';
import { MatConfirmDialogComponent } from './modules/mat-confirm-dialog/mat-confirm-dialog.component';



@NgModule({
  declarations: [
    AppComponent,
    AddAccountComponent,
    UpdateCustomerComponent,
    DeleteAccountComponent,
    CustomerDetailsComponent,
    AccountDetailsComponent,
    MatConfirmDialogComponent
  ],
  imports: [
    BrowserModule,
    MatGridListModule,
    MatFormFieldModule,
    SharedModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DefaultModule,
    HttpClientModule,
    ReactiveFormsModule,
   

  ],
  providers: [AccountService],
  bootstrap: [AppComponent],
  entryComponents:[MatConfirmDialogComponent]
})
export class AppModule { }
