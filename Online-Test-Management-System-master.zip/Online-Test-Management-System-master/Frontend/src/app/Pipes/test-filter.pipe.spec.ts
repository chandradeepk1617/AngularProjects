import { TestFilterPipe } from './test-filter.pipe';

describe('TestFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TestFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
