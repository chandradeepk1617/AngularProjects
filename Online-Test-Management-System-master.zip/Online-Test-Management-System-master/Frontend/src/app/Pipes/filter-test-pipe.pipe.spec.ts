import { FilterTestPipePipe } from './filter-test-pipe.pipe';

describe('FilterTestPipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTestPipePipe();
    expect(pipe).toBeTruthy();
  });
});
