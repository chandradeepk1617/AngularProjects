import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Leave } from '../leave';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';
import { DateValidation } from '../date';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Employee } from '../Employee';
@Component({
  selector: 'app-edit-leave',
  templateUrl: './edit-leave.component.html',
  styleUrls: ['./edit-leave.component.css']
})
export class EditLeaveComponent implements OnInit {
   index=0;
  id:number;
  AppliedLeaveFlag:boolean=false;
  logObj:Login
  leaveArr1:Leave[]=[];
  leaveArr2:Leave[]=[];
  empId:number;
  userName:string;
  errorFlag:boolean=false;
  successFlag=false;
  errorflag1=false;
  successFlag1=false;
  fromDate:Date;
  toDate:Date;
  appliedDate:Date=new Date();
  dateFlag=false;
  reason:string;
  leaveObj:Leave;
  form:FormGroup;
  date:string=this.appliedDate.toISOString().slice(0,10);
  addFlag=false;
  leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
    constructor(public empService:EmployeeService,public app:AppComponent,private router:Router,public fb:FormBuilder) { 
  
      this.userName=this.empService.userName;
    this.createForm();
    }
  
    ngOnInit(): void {
      this.empService.getLeaveDetails().subscribe(data=>this.leaveArr=data);
      
      this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
      this.empService.getLoginDetails().subscribe(data=>
        {this.loginArr=data;
          this.pendingLeaves();
        });
  
    }
    createForm() {
      this.form = this.fb.group({
        dateTo: ['', Validators.required ],
        dateFrom: ['', Validators.required ],
        reason:['',Validators.required]
      }, //{validator: this.dateLessThan('dateFrom', 'dateTo')}
      );
    }
    

  //   dateLessThan(from: string, to: string) {
  //     return (group: FormGroup): {[key: string]: any} => {
  //       let f = group.controls[from];
  //       let t = group.controls[to];
  //       if ((f.value >= t.value)||(f.value<this.appliedDate) ){
  //         return {
  //           dates: "Date from should be less than Date to"
  //         };
  //       }
  //       return {};
  //     }
  // }
  pendingLeaves()
  {
    this.logObj=this.loginArr.find(login=>login.userName===this.userName);
    console.log(this.logObj);
    this.empId=this.logObj.empId;
    this.leaveArr1.splice(0,this.leaveArr1.length);
    this.searchLeaves();
  
  }
  onSubmit()
  {
  this.add(this.form.value)
  }
  
  add(req1:DateValidation)
  {
    let fDate=new Date(req1.dateFrom);
    let tDate = new Date(req1.dateTo);
   if(this.appliedDate>fDate || fDate>tDate)
   {
     this.dateFlag=true;
   }
   else
   {
    this.fromDate=req1.dateFrom;
    this.toDate=req1.dateTo;
    this.reason=req1.reason;
  this.leaveObj.fromDate=this.fromDate;
  this.leaveObj.toDate=this.toDate;
  this.leaveObj.reason=this.reason;
  this.leaveObj.appliedDate=this.date;
  this.empService.edit(this.leaveObj,this.index,this.leaveObj.id);
  this.leaveArr2.push(this.leaveObj);
  this.successFlag1=false;
  this.addFlag=true;

  }
  }
    searchLeaves()
    {
    let count=0;
    let status='pending';  
    for(let leave of this.leaveArr)
    {
    if(leave.empId===this.empId)
    {
      if(leave.status===status)
      {
        this.leaveArr1.push(leave);
        count=count+1;
        
      }
      else
      {
   
    }
  }
    }
    if(count===0)
    {
      this.errorFlag=true;
    }
    else
    {
      this.AppliedLeaveFlag=true;
    }
    }
    close()
    {
      this.errorflag1=false;
      this.errorFlag=false;
      this.AppliedLeaveFlag=false;
      this.successFlag=false;
      this.router.navigate(['/employee']);
    }
    home()
    {
      this.errorflag1=false;
      this.errorFlag=false;
      this.AppliedLeaveFlag=false;
      this.successFlag=false;
      this.router.navigate(['/employee']);
      
    }
    close1()
    {
  
      this.errorflag1=false;
      this.errorFlag=false;
      this.AppliedLeaveFlag=true;
      this.successFlag=false;
    }
    edit()
  {
    let count=0;
    
    let index1=0;
    this.index=0;
    for(let leave of this.leaveArr)
    {
      console.log(this.id);

      if(leave.leaveId===this.id)
      {
        this.index=count;
        index1++;
        this.leaveObj=leave;
        
      }
      count=count+1;
    }
    if(index1===0)
    {
      this.errorflag1=true;
    }
    else
    {
    
      this.successFlag1=true;
      this.AppliedLeaveFlag=false;
    }
  }
  back()
  {
    this.dateFlag=false;
  }
}
