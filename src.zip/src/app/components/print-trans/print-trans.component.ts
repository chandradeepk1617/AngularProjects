import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-trans',
  templateUrl: './print-trans.component.html',
  styleUrls: ['./print-trans.component.css']
})
export class PrintTransComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
