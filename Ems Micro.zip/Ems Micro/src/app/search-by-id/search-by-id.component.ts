import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { Router } from '@angular/router';
import { Leave } from '../leave';
import { Login } from '../login';
import { retry, catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-search-by-id',
  templateUrl: './search-by-id.component.html',
  styleUrls: ['./search-by-id.component.css']
})
export class SearchByIdComponent implements OnInit {
Id:number=0;
searchIdFlag:boolean=false;
empById:Employee[]=[];
errorFlag:boolean=false;
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:any;
message:any;
idIsNullFlag:boolean=false;
  constructor(private router:Router,private empService:EmployeeService) { }

  ngOnInit(): void {
    
  }

  searchId()
  {
    if(this.Id===0)
    {
      this.idIsNullFlag=true;
    }
    else
    {
      this.idIsNullFlag=false;

    this.empService.getUserById(this.Id).subscribe(data=>
      {
        this.empArr=data;
        if(this.empArr.length===0)
        {
          this.errorFlag=true;
        }
        else
        {
          this.errorFlag=false;
        this.searchIdFlag=true;
        }
      },(error)=>
      {
        this.message=error.error;
        this.errorFlag=true;
        
      });
    console.log(this.Id);
    }

}
  back()
  {
    this.searchIdFlag=false;
    this.errorFlag=false;
    this.router.navigate(['/employee']);
  }
  back1()
  {
    this.errorFlag=false;
  }
  
}
