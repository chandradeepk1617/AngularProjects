import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Login } from './login';
import { Router } from '@angular/router';
import { Leave } from './leave';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'project';
  
  public loginarr:Login[]=[];
  public userName:string;
  public password:string;
  public loginFlag:boolean=false;
  public adminFlag:boolean=false;
  public managerFlag:boolean=false;
  public employeeFlag:boolean=false;
  public empFlag:boolean=false;
  loginArr:Login[]=[];
  leaveArr:Leave[]=[];
  constructor(public empservice:EmployeeService,private router:Router){
    this.router.navigate(['login']);
  }
  ngOnInit()
  {
    
  //  this.empservice.getLoginDetails().subscribe(data=>this.loginArr=data);
  //  this.empservice.getLeaveDetails().subscribe(data=>this.leaveArr=data);

  }
  public authenticate()
  {
    // this.loginarr=this.loginArr;
    // console.log(this.leaveArr);
    // console.log(this.loginarr);
    // console.log(this.userName);
    // console.log(this.password);
    // for(var i=0;i<this.loginarr.length;i++)
    // {

    //   if(this.loginarr[i].userName.localeCompare(this.userName)==0 && this.loginarr[i].password.localeCompare(this.password)==0)
    //   {
    //     this.loginFlag=true;
    //     if(this.loginarr[i].loginType.localeCompare('admin')==0)
    //     {
    //       this.adminFlag=true;
    //       this.router.navigate(['/admin']);
    //     }
    //     if(this.loginarr[i].loginType.localeCompare('manager')==0)
    //     {
    //       this.managerFlag=true;
          
    //       this.router.navigate(['/manager']);
    //     }
    //     if(this.loginarr[i].loginType.localeCompare('employee')==0)
    //     {
    //       console.log("HII")
    //       this.employeeFlag=true;
          
    //       this.router.navigate(['/employee']);
    //     }
    //   }
    // }
  }
}
