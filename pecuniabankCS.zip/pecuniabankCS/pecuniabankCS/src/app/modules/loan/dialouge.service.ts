import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmdialougeboxComponent } from './confirmdialougebox/confirmdialougebox.component';


@Injectable({
  providedIn: 'root'
})
export class DialougeService {

  constructor(private dialog :MatDialog) { }
  openConfirmDialog(msg){

    return this.dialog.open(ConfirmdialougeboxComponent,{
       width: '390px',
       panelClass: 'confirm-dialog-container',
       disableClose: true,
       data :{
         message : msg
       }
     });
   }
}
