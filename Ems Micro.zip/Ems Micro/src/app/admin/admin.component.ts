import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public addEmpFlag=false;
  
  public empName:string;
  public empId:number;
  public empSalary:number;
  public deptId:number;
  public dob:Date;
  public contactNumber:number;
  public managerId:number;
  public numberOfLeavesLeft:number;
  public designation:string;



  constructor() { }

  ngOnInit(): void {
  }
  public addEmployee()
  {
    this.addEmpFlag=true;
  }
  public setAddEmpFlag()
  {
    //new Employee()
  }

}
