import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';
import { Login } from '../login';
import { Leave } from '../leave';
import { Employee } from '../Employee';

@Component({
  selector: 'app-cancel-leave',
  templateUrl: './cancel-leave.component.html',
  styleUrls: ['./cancel-leave.component.css']
})
export class CancelLeaveComponent implements OnInit {
id:number;
  AppliedLeaveFlag:boolean=false;
  logObj:Login;
  leaveArr1:Leave[]=[];
  empId:number;
  userName:string;
  errorFlag:boolean=false;
  successFlag=false;
  errorflag1=false;
  idIndex:number=0;
  
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  
    constructor(public empService:EmployeeService,public app:AppComponent,private router:Router) { 
  
      this.userName=this.empService.userName;
     }
  
    ngOnInit(): void {
     
this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
this.empService.getLeaveDetails().subscribe(data=>
  {this.leaveArr=data;
  this.pendingLeaves();
});
  
    }
    pendingLeaves()
    {
      console.log("HI")
      this.logObj=this.loginArr.find(login=>login.userName===this.userName);
      console.log(this.logObj);
      this.empId=this.logObj.empId;
      this.leaveArr1.splice(0,this.leaveArr1.length);
      this.searchLeaves();
    
    }
    searchLeaves()
    {
    let count=0;
    let status='pending';  
    for(let leave of this.leaveArr)
    {
    if(leave.empId===this.empId)
    {
      if(leave.status===status)
      {
        this.leaveArr1.push(leave);
        count=count+1;
      }
      else
      {
   
    }
  }
    }
    if(count===0)
    {
      this.errorFlag=true;
    }
    else
    {
      this.AppliedLeaveFlag=true;
    }
    }
  cancel()
  {
    let count=0;
    let index=0;
    let index1=0;
    for(let leave of this.leaveArr)
    {
      console.log(this.id);

      if(leave.leaveId===this.id)
      {
        index=count;
        this.idIndex=leave.id;
        index1++;
      }
      count=count+1;
    }
    if(index1===0)
    {
      this.errorflag1=true;
    }
    else
    {
      console.log("inside last else");
      console.log(this.idIndex)
      this.empService.cancel(index,this.idIndex);
      this.successFlag=true;
    }
  }
  close()
  {
    this.errorflag1=false;
    this.errorFlag=false;
    this.AppliedLeaveFlag=false;
    this.successFlag=false;
    this.router.navigate(['/employee']);
  }
  home()
  {
    this.errorflag1=false;
    this.errorFlag=false;
    this.AppliedLeaveFlag=false;
    this.successFlag=false;
    this.router.navigate(['/employee']);
    
  }
  close1()
  {

    this.errorflag1=false;
    this.errorFlag=false;
    this.AppliedLeaveFlag=true;
    this.successFlag=false;
  }
}
