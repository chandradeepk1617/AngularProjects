import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Router } from '@angular/router';
import { Leave } from '../leave';
import { Employee } from '../Employee';
import { combineLatest } from 'rxjs';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
logObj:Login;
userName:string;
oldPassword:string;
newPassword:string;
confirmPassword:string;
index:number;
oldPasswordFlag=false;
newPasswordFlag=false;
successFlag=false;
password:string;

leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  constructor(public empService:EmployeeService,public app:AppComponent,public router:Router) {
this.userName=this.empService.userName;
this.password=this.empService.password
console.log(this.userName);
   }

  ngOnInit(): void {
this.empService.loginDetails(this.userName).subscribe(data=>
  {
    this.logObj=data;
    console.log(this.logObj);
  });
  }
  changePassword()
{ 
  console.log(this.logObj);

  if(this.oldPassword===this.logObj.password)
  {
    if(this.newPassword===this.confirmPassword)
    {
      this.logObj.password=this.newPassword;
      
     
this.empService.changePassword(this.logObj).subscribe(data=>console.log(data));
this.successFlag=true;

    }
    else{
      this.newPasswordFlag=true;
    }
  }
  else
  {
    this.oldPasswordFlag=true;
  }
}
close()
{
  this.successFlag=false;
  this.oldPasswordFlag=false;
  this.newPasswordFlag=false;
}
back()
{
  this.successFlag=false;
  this.oldPasswordFlag=false;
  this.newPasswordFlag=false;
  this.router.navigate(['/employee']);

}
logout()
{
  this.router.navigate(['login']);
}
}
