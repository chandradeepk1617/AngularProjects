import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-apply-loan',
  templateUrl: './apply-loan.component.html',
  styleUrls: ['./apply-loan.component.css']
})
export class ApplyLoanComponent implements OnInit {

  addForm:FormGroup;
  submitted:boolean=false;
  constructor(private formBuilder: FormBuilder, private router:Router){ }

  ngOnInit() {
    this.addForm =this.formBuilder.group({
      loan:['',[Validators.required,Validators.min(30000)]],
      asset:['',[Validators.required,Validators.min(100000)]],
      tenure:['',[Validators.required,Validators.min(1),Validators.max(5)]],
      password:['',[Validators.required]]
    });
  }

  addUser(){
    this.submitted =true;
    if(this.addForm.invalid)
    {
      return;
    }
    let loan =this.addForm.controls.loan.value;
    let asset = this.addForm.controls.asset.value;
    let tenure = this.addForm.controls.tenure.value;
    let pass = this.addForm.controls.password.value;
    if(loan < (asset-20000) && pass == "admin123")
      {
        alert("Loan Sanctioned!");
        console.log(this.addForm.value);
        this.router.navigate(['user']);
      }
      else if(loan < (asset-20000) && pass != "admin123"){
        this.invalidLogin =true;
      }
      else{
        this.invalidLoan=true;
      }
  }
  invalidLogin:boolean =false;
  invalidLoan:boolean =false;
  }
