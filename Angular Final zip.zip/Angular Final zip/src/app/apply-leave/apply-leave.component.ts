import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Employee } from '../Employee';
import { DateValidation } from '../date';
import { Leave } from '../leave';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { getLocaleDateFormat } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.css']
})
export class ApplyLeaveComponent implements OnInit {
leaveArr1:Leave[]=[];
  fromDate:Date;
toDate:Date;
reason:string;
empId:number;
mgrId:number;
appliedDate:Date=new Date();
date:string=this.appliedDate.toISOString().slice(0,10);
appDate:Date;
logObj:Login;
form:FormGroup;
userName:string;
emp:Employee;
leave:Leave;
addFlag:boolean=false;
dateFlag:boolean=false;
leaveId:number;
id:number;
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  constructor(public empService:EmployeeService,public app:AppComponent,public fb:FormBuilder,public router:Router) {
this.userName=this.empService.userName;

this.createForm();

   }

  ngOnInit(): void {
    this.empService.getLeaveDetails().subscribe(data=>this.leaveArr=data);
this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
  }
  fetchId()
  {
    this.leaveId=0;
    for(let leave of this.leaveArr)
    {
if(this.leaveId<leave.leaveId)
{
this.leaveId=leave.leaveId;
}
    }

  }
  createForm() {
    this.form = this.fb.group({
      dateTo: ['', Validators.required ],
      dateFrom: ['', Validators.required ],
      reason:['',Validators.required]
    }, //{validator: this.dateLessThan('dateFrom', 'dateTo')}
    );
  }
  
//   dateLessThan(from: string, to: string) {
//     return (group: FormGroup): {[key: string]: any} => {
//       let f = group.controls[from];
//       let t = group.controls[to];
//       if ((f.value >= t.value)||(f.value<this.appliedDate) ){
//         return {
//           dates: "Date from should be less than Date to"
//         };
//       }
//       return {};
//     }
// }
onSubmit()
{
  this.logObj=this.loginArr.find(l=>l.userName===this.userName)
this.empId=this.logObj.empId;
this.emp=this.empArr.find(e=>e.empId===this.empId)
this.mgrId=this.emp.managerId;
this.fetchId();
this.add(this.form.value)
}

add(req1:DateValidation)
{
  let fDate=new Date(req1.dateFrom);
  let tDate = new Date(req1.dateTo);
 if(this.appliedDate>fDate || fDate>tDate)
 {
   this.dateFlag=true;
 }
 else
 {
  this.fromDate=req1.dateFrom;
  this.toDate=req1.dateTo;
  this.reason=req1.reason;
  this.leaveId=this.leaveId+1;
  this.id=this.leaveId;
this.leave=new Leave(this.id,this.leaveId,this.fromDate,this.toDate,this.date,this.empId,this.mgrId,this.reason);

this.empService.add(this.leave);
this.leaveArr1.push(this.leave);
this.addFlag=true;
}
}
back()
{
  this.dateFlag=false;
  this.addFlag=false;
}
home()
{

  this.dateFlag=false;
  this.addFlag=false;
  this.router.navigate(['/employee']);
}
}
