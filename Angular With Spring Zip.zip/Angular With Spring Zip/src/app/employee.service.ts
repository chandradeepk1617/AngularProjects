import { Injectable } from '@angular/core';
import { Login } from './login';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './Employee';
import { Leave } from './leave';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  public userName:string;
  public password:string;

  constructor(private http:HttpClient) { 
  
  }
  
  public loginValidate(userName:string,password:string)
  {
    this.password=password;
    this.userName=userName;
    return this.http.get("http://localhost:8081/User/validate/"+userName+"/"+password)
  }
  public getUserByUserName(userName:string)
  {
    return this.http.get<Employee[]>("http://localhost:8081/User/UserName/"+userName)
  }
  public getUserById(id:number)
  {
    return this.http.get<Employee[]>("http://localhost:8081/User/id/"+id)

  }
  public getUserByName(name:string)
  {
    return this.http.get<Employee[]>("http://localhost:8081/User/name/"+name)

  }
  public getEmpIdByUserName(name:string)
  {
    return this.http.get("http://localhost:8081/User/empId/"+name)
  }
  public getLeavesByName(name:string)
  {
    return this.http.get<Leave[]>("http://localhost:8081/User/leaves/"+name)
  }
  public getPendingLeaves(name:string)
  {
    return this.http.get<Leave[]>("http://localhost:8081/User/leaves/pending/"+name)
  }
  public getLeaveById(id:number)
  {
    return this.http.get<Leave>("http://localhost:8081/User/leave/id/"+id)
  }
  public loginDetails(name:string)
  {
    return this.http.get<Login>("http://localhost:8081/User/loginDetails/"+name)
  }
  public cancelLeave(name:string,id:number)
  {
    return this.http.delete("http://localhost:8081/User/leave/delete/"+name+'/'+id,{responseType:'text' as 'json'})
  }
  public getAllLeaves()
  {
    return this.http.get<Leave[]>("http://localhost:8081/User/leaves")
  }
  public addLeave(leave:Leave)
  {
    return this.http.post("http://localhost:8081/User/leave/add",leave,{responseType:'text' as 'json'})
  }
  public editLeave(leave:Leave)
  {
    return this.http.put("http://localhost:8081/User/leave/edit",leave,{responseType:'text' as 'json'})
  }
public changePassword(login:Login)
{
  return this.http.put("http://localhost:8081/User/changePassword",login,{responseType:'text' as 'json'})
}

}
