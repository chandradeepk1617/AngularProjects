import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-pay-emi',
  templateUrl: './pay-emi.component.html',
  styleUrls: ['./pay-emi.component.css']
})
export class PayEmiComponent implements OnInit {

  loginForm: FormGroup;
  submitted:boolean =false;
  emi:number=2167.0;
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group(
      {
        password:['',Validators.required]
      }
    );
  }
  verifyLogin()
  {
    this.submitted =true;
    if(this.loginForm.invalid){
      return; 
    }

    
    let pass = this.loginForm.controls.password.value;
    if(pass == "admin123")
      {
        alert("EMI payment Successful!");
        this.router.navigate(['user'])
      }
      else{
        this.invalidLogin =true;
      }
  }
  invalidLogin:boolean =false;

}
