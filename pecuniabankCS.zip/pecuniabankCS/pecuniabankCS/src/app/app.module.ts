import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DefaultModule } from './layouts/default/default.module';
import { LoanModule } from './modules/loan/loan.module';
import { LoanService } from './modules/loan/loan.service';
import { NotificationService } from './modules/loan/notification.service';
import { DialougeService } from './modules/loan/dialouge.service';
import { ConfirmdialougeboxComponent } from './modules/loan/confirmdialougebox/confirmdialougebox.component';
import { AccountModule } from './modules/account/account.module';
import { AccountService } from './modules/account/account.service';
import { MatConfirmDialogComponent } from './modules/account/mat-confirm-dialog/mat-confirm-dialog.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DefaultModule,
    LoanModule,
    AccountModule
    
  ],
  providers: [LoanService,NotificationService,DialougeService,AccountService],
  bootstrap: [AppComponent],
  entryComponents:[ConfirmdialougeboxComponent,MatConfirmDialogComponent]
})
export class AppModule { }
