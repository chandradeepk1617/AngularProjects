import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';
import { Login } from './login';
import { Router } from '@angular/router';
import { Leave } from './leave';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'project';
  
  public loginarr:Login[]=[];
  public userName:string;
  public password:string;
  public loginFlag:boolean=false;
  public adminFlag:boolean=false;
  public managerFlag:boolean=false;
  public employeeFlag:boolean=false;
  public empFlag:boolean=false;
  loginArr:Login[]=[];
  leaveArr:Leave[]=[];
  loginForm: FormGroup;

  submitted:boolean =false;
  constructor(public empservice:EmployeeService,private router:Router,private formBuilder: FormBuilder){
    this.router.navigate(['/login']);
  }
  ngOnInit()
  {
    
  //  this.empservice.getLoginDetails().subscribe(data=>this.loginArr=data);
  //  this.empservice.getLeaveDetails().subscribe(data=>this.leaveArr=data);
  //  this.loginForm = this.formBuilder.group(
  //   {
  //     usrid:['',Validators.required],
  //     password:['',Validators.required]
  //   }
  // );

  }
//   public authenticate()
//   {
//     this.submitted=true;
//   if(this.loginForm.valid)
//   {
//     this.userName =this.loginForm.controls.usrid.value;
//     this.password= this.loginForm.controls.password.value;
// this.empservice.loginValidate(this.userName,this.password).subscribe(data=>
//   {
//     if(data===true)
//     {
//       this.router.navigate(['/employee']);
//       console.log("HI")
//       this.loginFlag=true;
//     }
//     else
//     {
//       console.log("FALSE");
//     }
//   });

//   }
//   else
//   {
//     return;
//   }

    // this.loginarr=this.loginArr;
    // console.log(this.leaveArr);
    // console.log(this.loginarr);
    // console.log(this.userName);
    // console.log(this.password);
    // for(var i=0;i<this.loginarr.length;i++)
    // {

    //   if(this.loginarr[i].userName.localeCompare(this.userName)==0 && this.loginarr[i].password.localeCompare(this.password)==0)
    //   {
    //     this.loginFlag=true;
    //     if(this.loginarr[i].loginType.localeCompare('admin')==0)
    //     {
    //       this.adminFlag=true;
    //       this.router.navigate(['/admin']);
    //     }
    //     if(this.loginarr[i].loginType.localeCompare('manager')==0)
    //     {
    //       this.managerFlag=true;
          
    //       this.router.navigate(['/manager']);
    //     }
    //     if(this.loginarr[i].loginType.localeCompare('employee')==0)
    //     {
    //       console.log("HII")
    //       this.employeeFlag=true;
          
    //       this.router.navigate(['/employee']);
    //     }
    //   }
    // }
  }

