import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';
import { Login } from '../login';
import { Leave } from '../leave';
import { Employee } from '../Employee';
import { LoginComponent } from '../login/login.component';
import { retry, catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-cancel-leave',
  templateUrl: './cancel-leave.component.html',
  styleUrls: ['./cancel-leave.component.css']
})
export class CancelLeaveComponent implements OnInit {
id:number;
  AppliedLeaveFlag:boolean=false;
  logObj:Login;
  leaveArr1:Leave[]=[];
  empId:number;
  userName:string;
  errorFlag:boolean=false;
  successFlag=false;
  errorflag1=false;
  idIndex:number=0;
  leaveObj:Leave;
  
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  message: any;
  
    constructor(public empService:EmployeeService,private router:Router) { 
  
      this.userName=this.empService.userName;
     }
  
    ngOnInit(): void {
      this.empService.getPendingLeaves(this.userName).subscribe(data=>
        {
          this.leaveArr=data;
          if(this.leaveArr.length===0)
          {
this.errorFlag=true;
          }
          else
          {
          
          this.AppliedLeaveFlag=true;
          }
        },(error)=>
        {
          this.message=error.error;
          this.errorFlag=true;
          
        });
//       this.empService.getLeaveDetails().subscribe(data=>this.leaveArr=data);
// this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
// this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
  
    }
  cancel()
  {
    let count=0;
    for(let leave of this.leaveArr)
    {
      console.log(this.id);

      if(leave.leaveId===this.id)
      {
        this.leaveObj=leave;
        count=count+1;
      }
      
    }
    if(count===0)
    {
      this.errorflag1=true;
    }
    else
    {
      this.empService.cancelLeave(this.empService.userName,this.leaveObj.leaveId).subscribe(data=>console.log(data))
      this.successFlag=true;
    }
  }
  close()
  {
    this.errorflag1=false;
    this.errorFlag=false;
    this.AppliedLeaveFlag=false;
    this.successFlag=false;
    this.router.navigate(['/employee']);
  }
  home()
  {
    this.errorflag1=false;
    this.errorFlag=false;
    this.AppliedLeaveFlag=false;
    this.successFlag=false;
    this.router.navigate(['/employee']);
    
  }
  close1()
  {

    this.errorflag1=false;
    this.errorFlag=false;
    this.AppliedLeaveFlag=true;
    this.successFlag=false;
  }
}
