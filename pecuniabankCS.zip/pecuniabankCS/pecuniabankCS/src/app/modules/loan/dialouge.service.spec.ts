import { TestBed } from '@angular/core/testing';

import { DialougeService } from './dialouge.service';

describe('DialougeService', () => {
  let service: DialougeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DialougeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
