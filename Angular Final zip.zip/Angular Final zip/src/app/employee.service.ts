import { Injectable } from '@angular/core';
import { Login } from './login';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './Employee';
import { Leave } from './leave';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  public empArr:Employee[]=[];
  public loginArr:Login[]=[];
  public leaveArr:Leave[]=[];
public userName:string;
public password:string;
  public url:string='./assets/login.json';
  public employeesurl:string='http://localhost:3000/employee';
public loginurl:string='http://localhost:3000/login';
public leavesurl:string='http://localhost:3000/leave';
  constructor(private http:HttpClient) { 
  
  }
  public getLoginDetails()
  {
    return this.http.get<Login[]>(this.loginurl);
  }
  public getLeaveDetails()
  {
return this.http.get<Leave[]>(this.leavesurl);
  }
  public getEmployeeDetails()
  {
return this.http.get<Employee[]>(this.employeesurl);
  }
  public changeEmpPassword(index:number,logObj:Login,id:number)
  {
    console.log(logObj);
    
this.loginArr[index]=logObj;
return this.http.put(this.loginurl+'/'+id,logObj).subscribe(data=>console.log(data));

  }
  public saveLoginDetails(userName:string,password:string)
  {
this.password=password;
this.userName=userName;
  }
  public add(leave:Leave)
  {

    this.leaveArr.push(leave);
    console.log(leave);
   return this.http.post(this.leavesurl,leave).subscribe(data=>console.log(data));
  }
  public cancel(index:number,id:any)
  {
    console.log(index);
    this.leaveArr.splice(index,1);
    this.http.delete(this.leavesurl+'/'+id).subscribe(data=>console.log(data));
    console.log(id);
  }
  public edit(leave:Leave,index:number,id:any)
  {
    console.log(leave);
    this.leaveArr[index]=leave;
    return this.http.put(this.leavesurl+'/'+id,leave).subscribe(data=>console.log(data));
  }
}
