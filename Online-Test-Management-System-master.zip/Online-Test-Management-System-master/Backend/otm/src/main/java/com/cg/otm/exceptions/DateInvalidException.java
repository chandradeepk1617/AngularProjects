package com.cg.otm.exceptions;

public class DateInvalidException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DateInvalidException(String message)
	{
	super(message);
	}
}
