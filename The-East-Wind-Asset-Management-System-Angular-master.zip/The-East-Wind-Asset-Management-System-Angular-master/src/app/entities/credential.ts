export interface Credential {
  username: string;
  password: string;
  designation: string;
}
