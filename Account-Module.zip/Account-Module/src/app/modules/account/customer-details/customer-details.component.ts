import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { AccountService } from 'src/app/modules/account/account.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  accountForm:FormGroup;
  accountNumber:number;
  accountExistsFlag:boolean;
  aadharFlag:boolean;
  accountFlag:boolean;
  customer:Customer;
  response:any;
  message: any;
  errorFlag: boolean;
  //new Customer(111111111111,'chandu',9963673280,'EHLPK7582G','Ghatkesar','Telangana','Hyderabad','India',501301,'Male');
  constructor(public service:AccountService) { }

  ngOnInit(): void {
    this.aadharFlag=true;
    this.accountExistsFlag=false;
    this.accountFlag=false;

    this.accountForm = new FormGroup({
      accountNo:new FormControl('',[Validators.required,Validators.pattern("[1-9][0-9]{9}")])
    })
  }
    search()
    {
      this.accountNumber=this.accountForm.get('accountNo').value;
      this.service.isAccountNumberExists(this.accountNumber).subscribe(data=>
        {
          this.response=data;
          if(this.response==true)
          {
            this.service.getCustomerDetails(this.accountNumber).subscribe(data=>
              {
                this.customer=data;
                this.aadharFlag=false;
                this.accountFlag=true;
              })
          }
          else
          {
            this.accountExistsFlag=true;
          }
        },(error)=>
        {
          this.message=error.error;
          this.errorFlag=true;
          
        })
      
  }
  close()
  {
    this.errorFlag=false;
    this.accountExistsFlag=false;
    this.accountForm.patchValue(
      {
        accountNo : ''
      }
    )
  }
  continue()
  {
    this.aadharFlag=true;
    this.accountFlag=false;
    this.accountForm.patchValue(
      {
      accountNo : null
      }
    )  
  }
  

}
