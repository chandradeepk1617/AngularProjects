import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  loginForm: FormGroup;
  submitted:boolean =false;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group(
      {
        deposit:['',[Validators.required,Validators.min(1)]],
        password:['',Validators.required]
      }
    );
  }
  verifyLogin()
  {
    this.submitted =true;
    if(this.loginForm.invalid){
      return; 
    }

    let usr =this.loginForm.controls.deposit.value;
    let pass = this.loginForm.controls.password.value;
    if(usr > 0 && pass == "admin123")
      {
        alert("Amount Deposited Successfully!");
        this.router.navigate(['user'])
      }
      else{
        this.invalidLogin =true;
      }
  }
  invalidLogin:boolean =false;
  }
