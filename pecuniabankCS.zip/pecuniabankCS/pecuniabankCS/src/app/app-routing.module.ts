import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from './layouts/default/default.component';
import { AccountDetailsComponent } from './modules/account/account-details/account-details.component';
import { AddAccountComponent } from './modules/account/add-account/add-account.component';
import { CustomerDetailsComponent } from './modules/account/customer-details/customer-details.component';
import { DeleteAccountComponent } from './modules/account/delete-account/delete-account.component';
import { UpdateCustomerComponent } from './modules/account/update-customer/update-customer.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { FetchloansComponent } from './modules/loan/fetchloans/fetchloans.component';
import { FetchrequestsComponent } from './modules/loan/fetchrequests/fetchrequests.component';
import { LoanrequestComponent } from './modules/loan/loanrequest/loanrequest.component';
import { PassbookComponent } from './modules/passbook/passbook.component';


const routes: Routes = [
  {  path:'',component:DefaultComponent,
  children:[
 {path:'',component: DashboardComponent},
 {path:'passbook',component:PassbookComponent} ,
 {path:'loan',component:LoanrequestComponent},
 {path:'getrequests',component:FetchrequestsComponent},
 {path:'getloans',component:FetchloansComponent},
 {path:'addaccount',component:AddAccountComponent},
 {path:'updatecustomer',component:UpdateCustomerComponent},
 {path:'deleteaccount',component:DeleteAccountComponent},
 {path:'customerdetails',component:CustomerDetailsComponent},
 {path:'accountdetails',component:AccountDetailsComponent},
           ]
  },

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
