import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passbook',
  templateUrl: './passbook.component.html',
  styleUrls: ['./passbook.component.css']
})
export class PassbookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
