package com.cg.otm.exceptions;

public class DataMismatchExcpetion extends Exception{

	private static final long serialVersionUID = 1L;
	
	public DataMismatchExcpetion() {
		super();
	}
	
	public DataMismatchExcpetion(String msg) {
		super(msg);
	}
	

}
