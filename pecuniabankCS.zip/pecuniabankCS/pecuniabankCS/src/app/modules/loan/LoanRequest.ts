export class LoanRequest{
    loanRequestId:number;
    accountNo:number;
    amount:number;
    loanType:string;
    rateOfInterest:number;
    tenure:number;
    creditScore:number;
    loanStatus:string;
    employeeId:number;
    public constructor( loanRequestId:number,accountNo:number,amount:number,loanType:string,rateOfInterest:number,tenure:number,creditScore:number,loanStatus:string,employeeId:number)
    {
        this.loanRequestId=loanRequestId;
        this.accountNo=accountNo;
        this.amount=amount;
        this.loanType=loanType;
        this.rateOfInterest=rateOfInterest;
        this.tenure=tenure;
        this.creditScore=creditScore;
        this.loanStatus=loanStatus;
        this.employeeId=employeeId;
    }
}