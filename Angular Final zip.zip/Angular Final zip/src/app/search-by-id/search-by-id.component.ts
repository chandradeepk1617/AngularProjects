import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { Router } from '@angular/router';
import { Leave } from '../leave';
import { Login } from '../login';

@Component({
  selector: 'app-search-by-id',
  templateUrl: './search-by-id.component.html',
  styleUrls: ['./search-by-id.component.css']
})
export class SearchByIdComponent implements OnInit {
Id:Number;
searchIdFlag:boolean=false;
empById:Employee[]=[];
errorFlag:boolean=false;
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  constructor(private router:Router,private empService:EmployeeService) { }

  ngOnInit(): void {
    this.empService.getLeaveDetails().subscribe(data=>this.leaveArr=data);
this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
    
  }

  searchId()
  {
    console.log(this.Id);
    let emp1:Employee=null;
    this.empById.splice(0,this.empById.length)
   
    
    
    for(let emp of this.empArr)
    {
      if(emp.empId===this.Id)
      {
    //emp1=this.service.empArr.find(e=>e.empId===this.Id);
  emp1=emp;
    this.empById.push(emp1);
    this.errorFlag=false;
    this.searchIdFlag=true;
    }

  }
  if(emp1===null)
  {
this.errorFlag=true;
this.searchIdFlag=false;
  }
}
  back()
  {
    this.searchIdFlag=false;
    this.errorFlag=false;
    this.router.navigate(['/employee']);
  }
  back1()
  {
    this.errorFlag=false;
  }
  
}
