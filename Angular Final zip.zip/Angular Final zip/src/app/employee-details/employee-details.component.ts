import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { Login } from '../login';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';
import { Leave } from '../leave';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
empById:Employee[]=[];
employeeDetailsFlag:boolean=false;
empId:number;
userName:string;
logObj:Login;
emp:Employee;
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  constructor(public app:AppComponent,private router:Router,private empService:EmployeeService) { 
   

  }

  ngOnInit(): void {
this.empService.getLeaveDetails().subscribe(data=>this.leaveArr=data);
this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
this.empService.getEmployeeDetails().subscribe(data=>
  {this.empArr=data;
    this.fetchDetails();
  });
this.userName=this.empService.userName;

  }
checkDetails()
{
  this.fetchDetails();
}
  fetchDetails()
  {
    for(let login of this.loginArr)
    {
      if(login.userName===this.userName)
      {
        this.logObj=login;
      }
      console.log("hi");
    }
    //this.logObj=this.loginArr.find(login=>login.userName===this.userName);
    console.log(this.logObj);
    this.empId=this.logObj.empId;
    
        
        this.empDetails();
  }
  empDetails()
  {
  console.log("hi");
    this.empById.splice(0,this.empById.length)
  
  this.emp=this.empArr.find(e=>e.empId===this.empId)
  this.empById.push(this.emp);
  this.employeeDetailsFlag=true;
  }
  back()
  {
    this.employeeDetailsFlag=false;
    this.router.navigate(['/employee']);
  }
}
