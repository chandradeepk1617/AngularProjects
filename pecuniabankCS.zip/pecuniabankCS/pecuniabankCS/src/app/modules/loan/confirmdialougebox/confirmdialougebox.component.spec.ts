import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmdialougeboxComponent } from './confirmdialougebox.component';

describe('ConfirmdialougeboxComponent', () => {
  let component: ConfirmdialougeboxComponent;
  let fixture: ComponentFixture<ConfirmdialougeboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmdialougeboxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmdialougeboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
