import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule } from '@angular/material/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatFormFieldModule} from '@angular/material/form-field'
import {MatInputModule} from '@angular/material/input';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { HttpClientModule } from '@angular/common/http';
import { LoanrequestComponent } from './loanrequest/loanrequest.component';
import {MatIconModule} from '@angular/material/icon';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { FetchrequestsComponent } from './fetchrequests/fetchrequests.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table';
import {MatSortModule} from '@angular/material/sort';
import { FetchloansComponent } from './fetchloans/fetchloans.component';
import { ConfirmdialougeboxComponent } from './confirmdialougebox/confirmdialougebox.component';
import {MatDialogModule} from '@angular/material/dialog';







@NgModule({
  declarations: [LoanrequestComponent, FetchrequestsComponent, FetchloansComponent, ConfirmdialougeboxComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatGridListModule,
    MatFormFieldModule,
   MatInputModule,
  MatRadioModule,
    MatSelectModule,
    MatCheckboxModule,
   MatNativeDateModule,
    MatButtonModule,
    HttpClientModule,
    MatIconModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatTableModule,
    MatSortModule,
    MatDialogModule,
    FormsModule

  ],
  exports: [
    
    ReactiveFormsModule,
    MatToolbarModule,
    MatGridListModule,
    MatFormFieldModule,
   MatInputModule,
  MatRadioModule,
    MatSelectModule,
    MatCheckboxModule,
   MatNativeDateModule,
    MatButtonModule,
    HttpClientModule,
    MatIconModule,
    MatSnackBarModule,
    MatPaginatorModule,
     MatTableModule,
    MatSortModule,
     MatDialogModule,
     FormsModule
   
    
  ],
})
export class LoanModule { }
