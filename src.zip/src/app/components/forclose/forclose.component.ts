import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-forclose',
  templateUrl: './forclose.component.html',
  styleUrls: ['./forclose.component.css']
})
export class ForcloseComponent implements OnInit {

  loginForm: FormGroup;
  submitted:boolean =false;
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group(
      {
        password:['',Validators.required]
      }
    );
  }
  verifyLogin()
  {
    this.submitted =true;
    if(this.loginForm.invalid){
      return; 
    }

    let pass = this.loginForm.controls.password.value;
    if(pass == "admin123")
      {
        let result = confirm("Do you want to foreclose loan?");
        if(result)
        {
        alert("Loan Foreclose Successful!");
        this.router.navigate(['user'])
        }
      }
      else{
        this.invalidLogin =true;
      }
  }
  invalidLogin:boolean =false;


}
