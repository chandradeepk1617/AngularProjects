import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Leave } from '../leave';
import { Router } from '@angular/router';
import { Employee } from '../Employee';
import { LoginComponent } from '../login/login.component';
import { retry, catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-applied-leaves',
  templateUrl: './applied-leaves.component.html',
  styleUrls: ['./applied-leaves.component.css']
})
export class AppliedLeavesComponent implements OnInit {
AppliedLeaveFlag:boolean=false;
logObj:Login;
leaveArr1:Leave[]=[];
empId:number;
userName:string;
errorFlag:boolean=false;
leaveArr:any;
loginArr:Login[]=[];
empArr:Employee[]=[];
 message: any;


  constructor(public empService:EmployeeService,private router:Router) { 

    this.userName=this.empService.userName;
  }

  ngOnInit(): void {
    this.empService.getLeavesByName(this.userName).subscribe(data=>
      {
        this.leaveArr=data;
        if(this.leaveArr.length===0)
        {
this.errorFlag=true;
        }
        else
        {
          this.errorFlag=false;
        
        this.AppliedLeaveFlag=true;
        }
      },(error)=>
      {
        this.message=error.error;
        this.errorFlag=true;
        
      }
      );
    

  }
  
  back()
  {
    this.AppliedLeaveFlag=false;
    this.router.navigate(['/employee']);
  }
  back1()
  {
this.errorFlag=false;
  }
  
}
