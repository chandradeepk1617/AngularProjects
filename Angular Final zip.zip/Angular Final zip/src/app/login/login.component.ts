import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Leave } from '../leave';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  invalidLogin:boolean=false;
  public loginarr:Login[]=[];
  public userName:string;
  public password:string;
  public loginFlag:boolean=false;
  public adminFlag:boolean=false;
  public managerFlag:boolean=false;
  public employeeFlag:boolean=false;
  public empFlag:boolean=false;
  loginArr:Login[]=[];
  leaveArr:Leave[]=[];
  loginForm: FormGroup;

  submitted:boolean =false;
  constructor(public empservice:EmployeeService,private router:Router,private formBuilder: FormBuilder,){}
  ngOnInit()
  {
    
   this.empservice.getLoginDetails().subscribe(data=>this.loginArr=data);
   this.empservice.getLeaveDetails().subscribe(data=>this.leaveArr=data);
   this.loginForm = this.formBuilder.group(
    {
      usrid:['',Validators.required],
      password:['',Validators.required]
    }
  );

  }
  public authenticate()
  {
    let count=0;
    this.submitted=true;
    this.invalidLogin=false;
  if(this.loginForm.valid)
  {
    this.userName =this.loginForm.controls.usrid.value;
    this.password= this.loginForm.controls.password.value;
this.empservice.saveLoginDetails(this.userName,this.password);

    this.loginarr=this.loginArr;
    console.log(this.leaveArr);
    console.log(this.loginarr);
    console.log(this.userName);
    console.log(this.password);
    
    for(var i=0;i<this.loginarr.length;i++)
    {

      if(this.loginarr[i].userName.localeCompare(this.userName)==0 && this.loginarr[i].password.localeCompare(this.password)==0)
      {
        this.loginFlag=true;
        if(this.loginarr[i].loginType.localeCompare('admin')==0)
        {
          count=count+1;
          this.adminFlag=true;
          this.router.navigate(['/admin']);

        }
        if(this.loginarr[i].loginType.localeCompare('manager')==0)
        {
          count=count+1;
          this.managerFlag=true;
          
          this.router.navigate(['/manager']);
        }
        if(this.loginarr[i].loginType.localeCompare('employee')==0)
        {
          count=count+1;
          console.log("HII")
          this.employeeFlag=true;
          
          this.router.navigate(['/employee']);
        }
      }
    }
  }
if(count===0)
{
this.invalidLogin=true;
}
}
}