export class Employee {
  employeeId: number;
  employeeName: string;
  employeeDepartment: string;
  employeeDesignation: string;
  username: string;
}
