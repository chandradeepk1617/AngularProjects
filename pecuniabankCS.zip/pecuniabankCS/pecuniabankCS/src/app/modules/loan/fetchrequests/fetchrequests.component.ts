import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DialougeService } from '../dialouge.service';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-fetchrequests',
  templateUrl: './fetchrequests.component.html',
  styleUrls: ['./fetchrequests.component.css']
})
export class FetchrequestsComponent implements OnInit {
  

  constructor(private service:LoanService,private dialogService:DialougeService) { }

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['loanRequestId', 'accountNo', 'amount', 'loanType', 'rateOfInterest','tenure','creditScore','accept','reject'];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  searchKey: string;


  ngOnInit() {
    this.refreshList(); 
   

  }
  refreshList(){
    this.service.getLoanRequests().subscribe(
  
      array=>
      {
              this.listData = new MatTableDataSource(array);
              this.listData.sort = this.sort;
              this.listData.paginator = this.paginator;
              // this.listData.filterPredicate = (data, filter) => {
              //   return this.displayedColumns.some(ele => {
              //     return ele != 'actions' && data[ele].toLowerCase().indexOf(filter) != -1;
              //   });
              // };
              
            });
  } 




  
  onSearchClear() {
    this.searchKey = "";
    this.applyFilter();
  }

  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }

  accept(loanRequestId:number)

  {
    this.dialogService.openConfirmDialog('Are you sure to accept this loan request?')
    .afterClosed().subscribe(res =>{
      if(res){
        console.log(loanRequestId)
    this.service.acceptloanRequest(loanRequestId).subscribe(
    data=>
    {
this.refreshList();
    },
    error=>
    {
console.log(error)
    }
  )
      }
    });
  }

   

  
  reject(loanRequestId:number)

  
  {
    this.dialogService.openConfirmDialog('Are you sure to reject this loan request?')
    .afterClosed().subscribe(res =>{
      if(res){
    
    this.service.rejectloanRequest(loanRequestId).subscribe(
    data=>
    {this.refreshList();

    },
    error=>
    {
      console.log(error)

    }

  )
      }
    });

  }
}
