import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
declare const $:any;
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  addForm: FormGroup;
  crt_pan:boolean;
  pan:any;

  planModel: any = {start_time: new Date() };
  submitted:boolean;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.submitted=false;
    this.crt_pan=false;


    this.addForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern("[A-Z][A-Z a-z]{2,30}")]],
      phone_Number: ['', [Validators.required, Validators.pattern("[6-9][0-9]{9}")]],
      sex:['',[Validators.required]],
      aadhar:['',[Validators.required]],
      pan:['',[Validators.required]],
      state: ['', [Validators.required, Validators.pattern("[A-Z a-z]{2,30}")]],
      city: ['', [Validators.required, Validators.pattern("[A-Z a-z]{2,30}")]],
      country: ['', [Validators.required, Validators.pattern("[A-Z a-z]{2,30}")]],
      zip_code: ['', [Validators.required, Validators.pattern("[0-9]{6}")]],
      address:['',[Validators.required]],
      DOB:['',[Validators.required]]
    });



    $(document).ready(function () {
      var currentDate = new Date();
      $('.disableFuturedate').datepicker({
        format: 'dd/mm/yyyy',
        autoclose:true,
        endDate: "currentDate",
        maxDate: currentDate
      }).on('changeDate', function (ev) {
        $(this).datepicker('hide');
      });
      $('.disableFuturedate').keyup(function () {
        if (this.value.match(/[^0-9]/g)) {
          this.value = this.value.replace(/[^0-9^-]/g, '');
        }
      });
    });




    $('[data-type="adhaar-number"]').keyup(function() {
      var value = $(this).val();
      value = value.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter(s => s.length > 0).join("-");
      $(this).val(value);
    });

    $('[data-type="adhaar-number"]').on("change, blur", function() {
      var value = $(this).val();
      var maxLength = $(this).attr("maxLength");
      if (value.length != maxLength) {
        $(this).addClass("highlight-error");
      } else {
        $(this).removeClass("highlight-error");
      }
    });


    $('#txtPANNumber').change(function (event) {
      var regExp = /[a-zA-z]{5}\d{4}[a-zA-Z]{1}/;
      var txtpan = $(this).val();
      if (txtpan.length == 10 ) {
        if( txtpan.match(regExp) ){
              this.crt_pan = true;
        }
        else {
          alert('Not a valid PAN number');
          event.preventDefault();
          var x = document.getElementById("snackbar1");
          x.className = "show";
          setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);

        }
      }
      else {
        alert('Please enter 10 digits for a valid PAN number');
        event.preventDefault();
        var x = document.getElementById("snackbar2");
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);

      }

      $(this).val('')

    });
  }

  submitInfo() {
    this.submitted = true;

    console.log(this.addForm.invalid )
    console.log(this.crt_pan)
    if (this.addForm.invalid || !this.crt_pan) {
      if(this.crt_pan == false)
      {
        var x = document.getElementById("snackbar3");
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);

      }
      return;
    }


    alert('submited')
  }


}
