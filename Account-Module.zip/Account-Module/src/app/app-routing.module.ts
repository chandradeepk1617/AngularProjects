import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from './layouts/default/default.component';
import { AccountDetailsComponent } from './modules/account/account-details/account-details.component';
import { AddAccountComponent } from './modules/account/add-account/add-account.component';
import { CustomerDetailsComponent } from './modules/account/customer-details/customer-details.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { DeleteAccountComponent } from './modules/account/delete-account/delete-account.component';
import { PassbookComponent } from './modules/passbook/passbook.component';
import { UpdateCustomerComponent } from './modules/account/update-customer/update-customer.component';

const routes: Routes = [
  {path:'',component:DefaultComponent,
  children:[{
    path:'',component: DashboardComponent
  },{
    path:'passbook',component:PassbookComponent
  },
{path:'addAccount',component:AddAccountComponent},
{path:'updateCustomer',component:UpdateCustomerComponent},
{path:'deleteAccount',component:DeleteAccountComponent},
{path:'accountDetails',component:AccountDetailsComponent},
{path:'customerDetails',component:CustomerDetailsComponent}]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
