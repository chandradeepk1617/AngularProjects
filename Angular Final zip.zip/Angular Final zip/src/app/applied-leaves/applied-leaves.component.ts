import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Leave } from '../leave';
import { Router } from '@angular/router';
import { Employee } from '../Employee';

@Component({
  selector: 'app-applied-leaves',
  templateUrl: './applied-leaves.component.html',
  styleUrls: ['./applied-leaves.component.css']
})
export class AppliedLeavesComponent implements OnInit {
AppliedLeaveFlag:boolean=false;
logObj:Login;
leaveArr1:Leave[]=[];
empId:number;
userName:string;
errorFlag:boolean=false;
leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];


  constructor(public empService:EmployeeService,public app:AppComponent,private router:Router) { 

    this.userName=this.empService.userName;
  }

  ngOnInit(): void {
   
    this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
    this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
    this.empService.getLeaveDetails().subscribe(data=>
      {this.leaveArr=data;
        this.appliedLeaves();

      });
    

  }
  appliedLeaves()
  {
    this.logObj=this.loginArr.find(login=>login.userName===this.userName);
    console.log(this.logObj);
    this.empId=this.logObj.empId;
    this.leaveArr1.splice(0,this.leaveArr1.length);
    this.searchLeaves();
    
    
  }
  searchLeaves()
  {
  let count=0;
    
  for(let leave of this.leaveArr)
  {
  if(leave.empId===this.empId)
  {
  this.leaveArr1.push(leave);
  count=count+1;
  }
  }
  if(count===0)
  {
    this.errorFlag=true;
  }
  else
  {
    this.AppliedLeaveFlag=true;
  }
  }
  back()
  {
    this.AppliedLeaveFlag=false;
    this.router.navigate(['/employee']);
  }
  back1()
  {
this.errorFlag=false;
  }
  editLeave()
  {
this.router.navigate(['/..']);
  }
  cancelLeave()
  {
this.router.navigate(['/.cancelLeave']);
  }
}
