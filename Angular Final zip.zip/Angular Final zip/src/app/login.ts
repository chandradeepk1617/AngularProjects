export class Login{
    
    id:number;
    userName:string;
    loginType:string;
    password:string;
    empId:number;
    constructor(id,userName,loginType,password,empId)
    {
        this.id=id;
        this.userName=userName;
        this.loginType=loginType;
        this.password=password;
        this.empId=empId;
    }

}