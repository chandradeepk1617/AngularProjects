import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoanEntity } from './loanEntity';
import { LoanRequest } from './LoanRequest';

@Injectable({
  providedIn: 'root'
})
export class LoanService {


  constructor(private httpClient: HttpClient) { }
  checkAccountNumber(accountNo:number)
  {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
    params:new HttpParams().set('accountNo',accountNo.toString())
    }
    return this.httpClient.get<Boolean>("http://localhost:9091/accountNo",httpOptions);
  }
  addLoanRequest(loanRequest:LoanRequest)
  {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    return this.httpClient.post<LoanRequest>("http://localhost:9091/loanrequest",loanRequest,httpOptions);
  }
  getLoanRequests():Observable<LoanRequest[]>
  {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })}
      return this.httpClient.get<LoanRequest[]>("http://localhost:9091/loanrequests",httpOptions);
  }

  getLoans():Observable<LoanEntity[]>
  { let httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }),
  params:new HttpParams().set('filter',"ongoing")
  }
  return this.httpClient.get<LoanEntity[]>("http://localhost:9092/loans",httpOptions);
  }

  acceptloanRequest(loanRequestId:number):Observable<LoanEntity>
  {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
    params:new HttpParams().set("loanRequestId",loanRequestId.toString())
                            .set("employeeId","123456")
    }
    return this.httpClient.put<LoanEntity>("http://localhost:9091/loanapproval",null,httpOptions);
  }

  rejectloanRequest(loanRequestId:number):Observable<Boolean>
  {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
    params:new HttpParams().set('loanRequestId',loanRequestId.toString())
                            
    }
    return this.httpClient.put<Boolean>("http://localhost:9091/rejectloan",null,httpOptions);
  }
  }

