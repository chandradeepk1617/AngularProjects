export class Asset {
  id: number;
  assetName: string;
  assetDescription: string;
  availability: string;
  allottedTo: object;
  assetCategory: string;
}
