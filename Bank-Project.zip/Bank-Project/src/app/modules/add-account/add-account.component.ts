import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Account } from 'src/app/shared/Account';
import { AccountService } from 'src/app/shared/services/account.service';
import { NotificationService } from 'src/app/shared/services/notification.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {
addForm:FormGroup;
searchFlag:boolean;
aadharFlag:boolean;
accountFlag:boolean
aadharForm:FormGroup;
aadharExistsFlag:boolean;
aadharNumber:number;

account:Account;
response:any;
  message: any;
  errorFlag: boolean=false;
  constructor(public service:AccountService,public notification:NotificationService) { }

  ngOnInit(): void {
    this.aadharFlag=true;
    this.accountFlag=false;
    this.searchFlag=false;
    this.addForm = new FormGroup({
      aadhar: new FormControl('',[Validators.required,Validators.pattern("[1-9][0-9]{11}")]),
      name: new FormControl('', [Validators.required,Validators.pattern("[A-Z][a-z ]{2,15}")]),
      contact: new FormControl('', [Validators.required,Validators.pattern("[6-9][0-9]{9}")]),
      pan: new FormControl('', [Validators.required, Validators.pattern("[A-Z]{5}[0-9]{4}[A-Z]")]),
     address: new FormControl('',[Validators.required,Validators.pattern("[A-Za-z][A-Za-z -/]{6,20}")]),
      
     city: new FormControl('',[Validators.required,Validators.pattern("[A-Z][a-z]{3,10}")]),
     state: new FormControl('',[Validators.required,Validators.pattern("[A-Z][a-z]{3,10}")]),
     country: new FormControl('',[Validators.required,Validators.pattern("[A-Z][a-z]{3,10}")]),
      gender: new FormControl('',[Validators.required]),
      zipCode: new FormControl('', [Validators.required,Validators.pattern("[1-9][0-9]{5}")]),
    });
this.aadharForm = new FormGroup({
  aadharNo:new FormControl('',[Validators.required,Validators.pattern("[1-9][0-9]{11}")])
})
   
  }
  search()
  {
    this.aadharNumber=this.aadharForm.get('aadharNo').value;
    this.service.isAadharExists(this.aadharNumber).subscribe(data=>{
      this.response=data;
      if(this.response==false)
      {
        this.aadharExistsFlag=true;
      }
      else
      {
        this.aadharFlag=false;
    this.accountFlag=false;
    this.searchFlag=true;
    this.addForm.patchValue(
      {
        aadhar : this.aadharForm.get('aadharNo').value
      }
    )
      }


    })
    


  }
  onSubmit()
  {
    this.service.addAccount(this.addForm.value).subscribe(data=>
      {this.account=data;
        this.aadharFlag=false;
    this.accountFlag=true;
    this.searchFlag=false;
    this.onClear();
      },(error)=>
      {
        this.message=error.error;
        this.errorFlag=true;
        
      }
      );
      this.notification.success('::Submitted successfully');
 
      
  }
    close()
  {
    this.errorFlag=false;
this.aadharExistsFlag=false;
this.aadharForm.patchValue(
  {
    aadharNo : ''
  }
)

  }
onClear()
{
  this.addForm.patchValue(
    {
      
      name:'',
      contact:'',
      pan:'',
      address:'',
      state:'',
      city:'',
      country:'',
      zipCode:'',
      gender:'Male'
    }
  )
  

}
continue()
{
  this.aadharFlag=true;
  this.accountFlag=false;
  this.searchFlag=false;
  this.aadharForm.patchValue(
    {
    aadharNo : null
    }
  )  
}
}
