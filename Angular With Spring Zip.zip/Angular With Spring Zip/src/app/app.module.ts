import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { ManagerComponent } from './manager/manager.component';
import { EmployeeComponent } from './employee/employee.component';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { SearchByIdComponent } from './search-by-id/search-by-id.component';
import { SearchByNameComponent } from './search-by-name/search-by-name.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { AppliedLeavesComponent } from './applied-leaves/applied-leaves.component';
import { EditLeaveComponent } from './edit-leave/edit-leave.component';
import { CancelLeaveComponent } from './cancel-leave/cancel-leave.component';
import { ChangePasswordComponent } from './change-password/change-password.component'
import { EmployeeService } from './employee.service';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    ManagerComponent,
    EmployeeComponent,
    SearchByIdComponent,
    SearchByNameComponent,
    EmployeeDetailsComponent,
    ApplyLeaveComponent,
    AppliedLeavesComponent,
    EditLeaveComponent,
    CancelLeaveComponent,
    ChangePasswordComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
