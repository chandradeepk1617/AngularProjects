import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-calc-emi',
  templateUrl: './calc-emi.component.html',
  styleUrls: ['./calc-emi.component.css']
})
export class CalcEmiComponent implements OnInit {


  constructor(private formBuilder: FormBuilder, private router:Router) { }

  ngOnInit() {
   
  }
  
}
