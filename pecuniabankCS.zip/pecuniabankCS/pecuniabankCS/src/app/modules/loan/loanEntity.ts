export class LoanEntity
{
    loanId:number;
    accountNo:number;
    amount:number;
    loanType:string;
    rateOfInterest:number;
    tenure:number;
    emi:number;
    approvedDate:Date;
    loanStatus:string;
    employeeId:number;
    public constructor( loanId:number,accountNo:number,amount:number,loanType:string,rateOfInterest:number,tenure:number,emi:number,approvedDate:Date,loanStatus:string,employeeId:number)
    {
        this.loanId=loanId;
        this.accountNo=accountNo;
        this.amount=amount;
        this.loanType=loanType;
        this.rateOfInterest=rateOfInterest;
        this.tenure=tenure;
        this.emi=emi;
        this.approvedDate=approvedDate;
        this.loanStatus=loanStatus;
        this.employeeId=employeeId;
    }
}