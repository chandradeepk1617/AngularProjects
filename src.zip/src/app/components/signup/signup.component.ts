import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  addForm:FormGroup;
  submitted:boolean=false;
  constructor(private formBuilder: FormBuilder, private router:Router) { }
  
  ngOnInit() {
    
      
      this.addForm =this.formBuilder.group({
        firstName:['',[Validators.required, Validators.pattern("[A-Z][A-Z a-z]{2,14}")]],
        lastName:['',[Validators.required,Validators.pattern("[a-zA-Z]{3,14}")]],
        uid:['',[Validators.required,Validators.pattern("[0-9]{12}")]],
        mobileNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]],
        deposit:['',[Validators.required,Validators.min(50000)]],
        email:['',[Validators.required,Validators.email]],
        usrid:['',[Validators.required,Validators.pattern("[A-Z a-z]{8}")]],
        password:['',[Validators.required, Validators.minLength(6),Validators.maxLength(12)]],
      });
    }
  

  addUser(){
    this.submitted =true;
    if(this.addForm.invalid)
    {
      return;
    }
    console.log(this.addForm.value);
  }
  
}
