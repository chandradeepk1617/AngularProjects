import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Account } from '../Account';
import { AccountService } from 'src/app/modules/account/account.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  accountForm:FormGroup;
  accountNumber:number;
  accountExistsFlag:boolean;
  aadharFlag:boolean;
  accountFlag:boolean;
  response:any;
  message:any;
  errorFlag:boolean=false;
  
  accountObj:Account;
  constructor(public service:AccountService) { }

  ngOnInit(): void {
    this.aadharFlag=true;
    this.accountExistsFlag=false;
    this.accountFlag=false;
    this.accountForm = new FormGroup({
      accountNo:new FormControl('',[Validators.required,Validators.pattern("[1-9][0-9]{9}")])
    })
  }
  search()
  {
    this.accountNumber=this.accountForm.get('accountNo').value;
    this.service.isAccountNumberExists(this.accountNumber).subscribe(data=>
      {
        this.response=data;
        if(this.response==true)
        {
          this.service.getAccountDetails(this.accountNumber).subscribe(data=>
            {
              this.accountObj=data;
              this.aadharFlag=false;
              this.accountFlag=true;
            }
            
          )
        }
        else
        {
          this.accountExistsFlag=true;
        }

      },(error)=>
      {
        this.message=error.error;
        this.errorFlag=true;
        
      })
   
}
close()
{
  this.accountExistsFlag=false;
  this.errorFlag=false;
  this.accountForm.patchValue(
    {
      accountNo : ''
    }
  )
}
continue()
{
  this.aadharFlag=true;
  this.accountFlag=false;
  this.accountForm.patchValue(
    {
    accountNo : null
    }
  )  
}
}