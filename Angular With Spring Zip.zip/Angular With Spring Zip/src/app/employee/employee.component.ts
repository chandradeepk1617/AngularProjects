import { Component, OnInit,Input} from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Leave } from '../leave';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
userName:string;

  constructor(public service:EmployeeService,private route:Router,public app:AppComponent) { 
    this.userName=this.service.userName;
  }

  ngOnInit(): void {
  }
}
