import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog,MatDialogConfig} from '@angular/material/dialog';
import { Customer } from 'src/app/shared/Customer';
import { AccountService } from 'src/app/shared/services/account.service';
import { DialogService } from 'src/app/shared/services/dialog.service';
import { NotificationService } from 'src/app/shared/services/notification.service';

@Component({
  selector: 'app-delete-account',
  templateUrl: './delete-account.component.html',
  styleUrls: ['./delete-account.component.css']
})
export class DeleteAccountComponent implements OnInit {
  accountForm:FormGroup;
  accountNumber:number;
  accountExistsFlag:boolean;
  aadharFlag:boolean;
  deleteFlag:boolean;
  response:any;
  message: any;
  errorFlag: boolean=false;
 
  constructor(private service:AccountService,
    private dialog:MatDialog,
    private notification:NotificationService,
    private dialogService:DialogService) { }

  ngOnInit(): void {
    this.aadharFlag=true;
    this.accountExistsFlag=false;
    this.deleteFlag=false;

    this.accountForm = new FormGroup({
      accountNo:new FormControl('',[Validators.required,Validators.pattern("[1-9][0-9]{9}")])
    })
  }
  search()
  {
    this.accountNumber=this.accountForm.get('accountNo').value;
    this.service.isAccountNumberExists(this.accountNumber).subscribe(data=>{
      this.response=data;
      if(this.response==true)
      {
        this.dialogService.openConfirmDialog().afterClosed().subscribe(res=>
          {
            if(res==true)
            {
              this.deleteFlag=true;
              this.notification.warn("! Deleted Sccessfully");
            }
          },(error)=>
          {
            this.message=error.error;
            this.errorFlag=true;
            
          });
        //if(confirm('Are You sue to delete this account'))
      }
    
        
      else{
        this.accountExistsFlag=true;
      }
    })
   
  }
  close()
  {
    this.errorFlag=false;
    this.aadharFlag=true;
    this.accountExistsFlag=false;
    this.deleteFlag=false;
    this.accountForm.patchValue(
      {
        accountNo:''
      }
    )
  }

}
