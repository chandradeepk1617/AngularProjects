import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Account } from '../Account';
import { Customer } from '../Customer';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
account:Account
  constructor(private http:HttpClient) { }
  public addAccount(customer:Customer)
  {
    return this.http.post<Account>("http://localhost:8081/add",customer);
  }
public isAccountNumberExists(accountNo:number)
{
  return this.http.get("http://localhost:8081/account/valid/"+accountNo);
}
public isAadharExists(aadhar:number)
{
  return this.http.get("http://localhost:8081/aadhar/valid/"+aadhar);
}
public updateCustomerDetails(customer:Customer,accountNo:number)
{
  return this.http.put<Customer>("http://localhost:8081/update/customer/"+accountNo,customer);
}
public getCustomerDetails(accountNo:number)
{
  return this.http.get<Customer>("http://localhost:8081/customer/accountNo/"+accountNo);
}
public getAccountDetails(accountNo:number)
{
  return this.http.get<Account>("http://localhost:8081/account/accountNo/"+accountNo);
}
public deleteAccount(accountNo:number)
{
  return this.http.delete("http://localhost:8081/delete/"+accountNo)
}
public getAll()
{
  return this.http.get<Account[]>("http://localhost:8081/all");
}
}
