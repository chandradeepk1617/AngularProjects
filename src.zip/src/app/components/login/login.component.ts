import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;

  submitted:boolean =false;
  //Constructor Dependency Injection. It makes your application loosely typed.

  //formBuilder to build form elements with default values and attributes
  //
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  //Life cycle hook 
  ngOnInit() {
    this.loginForm = this.formBuilder.group(
      {
        usrid:['',Validators.required],
        password:['',Validators.required]
      }
    );
  }
  verifyLogin()
  {
    this.submitted =true;
    if(this.loginForm.invalid){
      return; 
    }

    let usr =this.loginForm.controls.usrid.value;
    let pass = this.loginForm.controls.password.value;
    if(usr == "user" && pass == "user123")
      {
        localStorage.usr = usr;
        sessionStorage.usr = usr;
        this.router.navigate(['user'])
      }
      else{
        this.invalidLogin =true;
      }
  }
  invalidLogin:boolean =false;
  

}
