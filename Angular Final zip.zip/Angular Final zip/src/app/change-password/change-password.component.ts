import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Router } from '@angular/router';
import { Leave } from '../leave';
import { Employee } from '../Employee';
import { combineLatest } from 'rxjs';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
logObj:Login;
userName:string;
oldPassword:string;
newPassword:string;
confirmPassword:string;
index:number;
oldPasswordFlag=false;
newPasswordFlag=false;
successFlag=false;

leaveArr:Leave[]=[];
loginArr:Login[]=[];
empArr:Employee[]=[];
  constructor(public empService:EmployeeService,public app:AppComponent,public router:Router) {
this.userName=this.empService.userName;
console.log(this.userName);
   }

  ngOnInit(): void {
    this.empService.getLeaveDetails().subscribe(data=>this.leaveArr=data);
this.empService.getLoginDetails().subscribe(data=>this.loginArr=data);
this.empService.getEmployeeDetails().subscribe(data=>this.empArr=data);
  }
fetchDetails()
{
  let count=0;    
for(let login of this.loginArr)
{
  console.log(login.userName);
  if(login.userName===this.userName)
  {
    this.logObj=login;
    this.index=count;
    console.log(this.logObj);
    console.log(login);

  }
count++;
console.log("hi")
}
}
  changePassword()
{
  this.fetchDetails();
  console.log(this.logObj.password)
  if(this.oldPassword===this.logObj.password)
  {
    if(this.newPassword===this.confirmPassword)
    {
      this.logObj.password=this.newPassword;
      alert(this.logObj.id);
      console.log(this.logObj.id)
this.empService.changeEmpPassword(this.index,this.logObj,this.logObj.id);
this.successFlag=true;
    }
    else{
      this.newPasswordFlag=true;
    }
  }
  else
  {
    this.oldPasswordFlag=true;
  }
}
close()
{
  this.successFlag=false;
  this.oldPasswordFlag=false;
  this.newPasswordFlag=false;
}
back()
{
  this.successFlag=false;
  this.oldPasswordFlag=false;
  this.newPasswordFlag=false;
  this.router.navigate(['/employee']);
}
}
